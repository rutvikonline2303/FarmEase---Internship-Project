var firebaseConfig = {
    apiKey: "AIzaSyA2SnXm0OFmo4N0k5YAm9vSuFwx40y1hyA",
    authDomain: "emailauth-cea10.firebaseapp.com",
    projectId: "emailauth-cea10",
    storageBucket: "emailauth-cea10.appspot.com",
    messagingSenderId: "517342761657",
    appId: "1:517342761657:web:801b3e6dc0b1c5c7300168"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
// Initialize Firebase
  //firebase.initializeApp(firebaseConfig);
  //make auth and firebase references 
  const auth=firebase.auth();
 // const db=firebase.firestore();


  //update firebase settings
 // db.settings({timestampsInSnapshots: true});
